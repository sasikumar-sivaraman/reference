//orig. code author https://twitter.com/thecodeplayer
// original source:
// http://thecodeplayer.com/walkthrough/css3-breadcrumb-navigation
/*
Forked and modified by Stan Williams http://stanwilliams.net http://stans-songs.com  https://codepen.io/Stanssongs

*/
/**
 * StyleFix 1.0.3 & PrefixFree 1.0.7
 * @author Lea Verou
 * MIT license
 */