package com.luv2code.demo.datasources.dao;

import java.util.List;

import com.luv2code.demo.datasources.entity.Employee;

public interface EmployeeDAO {

	public List<Employee> getEmployees();
		
}
