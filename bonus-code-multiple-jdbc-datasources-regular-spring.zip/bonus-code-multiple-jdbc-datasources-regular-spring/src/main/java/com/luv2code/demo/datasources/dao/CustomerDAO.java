package com.luv2code.demo.datasources.dao;

import java.util.List;

import com.luv2code.demo.datasources.entity.Customer;

public interface CustomerDAO {

	public List<Customer> getCustomers();
	
}
