declare var Stripe: any;
declare var elements: any;